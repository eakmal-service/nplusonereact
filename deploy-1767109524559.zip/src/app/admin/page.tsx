import AdminDashboard from '@/admin/pages/Dashboard';
 
export default function AdminPage() {
  return <AdminDashboard />;
} 